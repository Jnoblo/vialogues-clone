# Vialogues Clone — Version Replit (SQLite intégrée)

## 🚀 Lancement sur Replit

1. Importez ce fichier ZIP sur [https://replit.com](https://replit.com)
2. Ouvrez le projet et cliquez sur **Run**
3. Le serveur démarre automatiquement et crée une base SQLite (`db.sqlite`)
4. L'application s'affiche sur une URL publique Replit (ex: https://vialogues-clone.yourname.repl.co)

### 🧠 Compte démo
- **Email** : demo@vialogues.local
- **Mot de passe** : admin123
- Rôle : administrateur

